const sources = [
    {
        "sourceType": "user",
        "fetch": "/api/__sitemap__/urls"
    },
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/faq"
            },
            {
                "loc": "/test"
            },
            {
                "loc": "/about"
            },
            {
                "loc": "/"
            },
            {
                "loc": "/contact"
            },
            {
                "loc": "/profiles"
            },
            {
                "loc": "/services"
            },
            {
                "loc": "/news"
            },
            {
                "loc": "/references"
            },
            {
                "loc": "/news-detail"
            },
            {
                "loc": "/product-detail"
            },
            {
                "loc": "/products"
            },
            {
                "loc": "/product-category"
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
