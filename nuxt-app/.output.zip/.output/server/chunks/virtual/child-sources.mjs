const sources = {};

export { sources };
//# sourceMappingURL=child-sources.mjs.map
