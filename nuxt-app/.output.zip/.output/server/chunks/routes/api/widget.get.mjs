import { e as defineEventHandler, g as getQuery, f as createError } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import 'consola';
import 'ipx';
import 'node:path';
import 'node:crypto';

const widget_get = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const widgetId = query.id;
    const sidebarId = query.sidebar || "nouveau-template-01";
    if (!widgetId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Widget ID is required"
      });
    }
    const response = await fetch(
      `https://api.logic-design-solutions.com/wp-json/custom/v1/widgets`
    );
    if (!response.ok) {
      throw createError({
        statusCode: response.status,
        statusMessage: `Failed to fetch widgets: ${response.statusText}`
      });
    }
    let widgetsData;
    try {
      widgetsData = await response.json();
    } catch (parseError) {
      console.error("Failed to parse widgets JSON:", parseError);
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to parse widgets data from API"
      });
    }
    if (!widgetsData || typeof widgetsData !== "object") {
      throw createError({
        statusCode: 500,
        statusMessage: "Invalid widgets data format"
      });
    }
    const sidebarWidgets = widgetsData[sidebarId] || [];
    const widget = sidebarWidgets.find((w) => w.id === widgetId);
    if (!widget) {
      throw createError({
        statusCode: 404,
        statusMessage: `Widget ${widgetId} not found in sidebar ${sidebarId}`
      });
    }
    if (widget.content) {
      return widget;
    }
    const contentResponse = await fetch(
      `https://api.logic-design-solutions.com/wp-json/custom/v1/widget-content/${widgetId}`
    );
    if (contentResponse.ok) {
      const contentData = await contentResponse.json();
      return { ...widget, ...contentData };
    }
    return widget;
  } catch (error) {
    const err = error;
    console.error("Widget API error:", err);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: err.message || "Failed to fetch widget"
    });
  }
});

export { widget_get as default };
//# sourceMappingURL=widget.get.mjs.map
