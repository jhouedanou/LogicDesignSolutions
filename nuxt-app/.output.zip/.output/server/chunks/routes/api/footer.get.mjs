import { e as defineEventHandler, f as createError } from '../../_/nitro.mjs';
import { readFileSync } from 'fs';
import { join } from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import 'consola';
import 'ipx';
import 'node:path';
import 'node:crypto';

const footer_get = defineEventHandler(() => {
  try {
    const filePath = join(process.cwd(), "public/data/footer.json");
    const data = readFileSync(filePath, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to load footer data"
    });
  }
});

export { footer_get as default };
//# sourceMappingURL=footer.get.mjs.map
