import { c as defineSitemapEventHandler } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import 'consola';
import 'ipx';
import 'node:path';
import 'node:crypto';

const urls = defineSitemapEventHandler(async () => {
  const urls = [];
  const staticPages = [
    { loc: "/", priority: 1, changefreq: "weekly" },
    { loc: "/about", priority: 0.8, changefreq: "monthly" },
    { loc: "/services", priority: 0.8, changefreq: "monthly" },
    { loc: "/products", priority: 0.9, changefreq: "weekly" },
    { loc: "/news", priority: 0.9, changefreq: "daily" },
    { loc: "/references", priority: 0.7, changefreq: "monthly" },
    { loc: "/profiles", priority: 0.7, changefreq: "monthly" },
    { loc: "/contact", priority: 0.8, changefreq: "monthly" },
    { loc: "/faq", priority: 0.6, changefreq: "monthly" }
  ];
  urls.push(...staticPages);
  try {
    const newsResponse = await fetch("https://api.logic-design-solutions.com/wp-json/wp/v2/posts?per_page=100&_fields=slug,modified");
    if (newsResponse.ok) {
      const posts = await newsResponse.json();
      for (const post of posts) {
        urls.push({
          loc: `/news/${post.slug}`,
          lastmod: post.modified,
          priority: 0.7,
          changefreq: "weekly"
        });
      }
    }
  } catch (error) {
    console.error("Error fetching news for sitemap:", error);
  }
  try {
    const productsResponse = await fetch("https://api.logic-design-solutions.com/wp-json/wp/v2/product?per_page=100&_fields=slug,modified");
    if (productsResponse.ok) {
      const products = await productsResponse.json();
      for (const product of products) {
        urls.push({
          loc: `/products/${product.slug}`,
          lastmod: product.modified,
          priority: 0.8,
          changefreq: "weekly"
        });
      }
    }
  } catch (error) {
    console.error("Error fetching products for sitemap:", error);
  }
  return urls;
});

export { urls as default };
//# sourceMappingURL=urls.mjs.map
